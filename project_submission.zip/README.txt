Package name:project_submission.zip

~Package Contents~
folders: "testing/cat" "testing/dog" "hd_testing/hot_dog" "hd_testing/not_hot_dog" "theData/HotdogImages/hot_dog" "theData/HotdogImages/not_hot_dog"
code: final_solution.m
code: final_project_starter_cap4630_with_answers.m

~Instructions~
1. Unzip "project_submission.zip"
2. Place the following in extracted "project_submission" folder:
	0)
	hotdogs and not hotdogs: "train" folder provided in Kaggle's bundled zip archive: link: https://www.kaggle.com/dansbecker/hot-dog-not-hot-dog
	rename the above "train" folder to "hd_train"
	cats and dogs: "train" folder provided in Kaggle's "train.zip": link:
	https://www.kaggle.com/c/dogs-vs-cats/data

	OPTIONS:  1)go to the mentioned locations to find each file OR 2)(*RECOMMENDED*)use my google drive link having all files:
	1)
	(Below folders and files are provided within "cats_dogs_starter.zip")
	"data" folder with its contents
	"cat.jpg"
	"dog.jpg"
	"doge.jpg"
	and
	hotdogs and not hotdogs: "train" folder provided in Kaggle's bundled zip archive: link: https://www.kaggle.com/dansbecker/hot-dog-not-hot-dog
	rename the above "train" folder to "hd_train"
	cats and dogs: "train" folder provided in Kaggle's "train.zip": link:
	https://www.kaggle.com/c/dogs-vs-cats/data
	images of your choice by names:
	"hotdog.jpg"
	"hotdoge.jpg"
	"notHotdog.jpg"

				OR
		
	2) 
	Open "AI_Project_Dependencies" folder here: https://drive.google.com/drive/folders/1zen7QYN5mrXlUXcGpfrrz4UsgqgOmlbP?usp=sharing
	Select all the content within and drag into "project_submission" folder.

3. 
In folder "testing":
*There should be no other folders or images in the "testing" folder,
other than the ones mentioned below*
*Recommendation: Use contents of "test1.zip" provided by Kaggle from Dogs vs Cats dataset*
Expected File format: X.jpg, where X is a postive integer 
Place the cat images that you would like to test classify in the "cat" folder
Place the dog images that you would like to test classify in the "dog" folder

In folder "hd_testing":
*There should be no other folders or images in the "hd_testing" folder,
other than the ones mentioned below*
*Recommendation use some test images available in "test" folder
Place the hotdog images that you would like to test classify in the "hot_dog" folder
Place the not hotdog images that you would like to test classify in the "not_hot_dog" folder

4. Either:
	1) Place your own content into "theData/HotdogImages/hot_dog" and "theData/HotdogImages/not_hot_dog" with names in format hotdog.*.jpg and 	notHotdog.*.jpg, respectively.

					OR

	2)(SKIP THIS STEP IF "theData" WAS DOWNLOADED FROM GOOGLE DRIVE)Feel free to download "theData" archive and extract "theData" folder(it is already populated with training files) from following link to replace 	empty "theData" folder provided in the project_submission.zip: https://drive.google.com/drive/folders/1APN1c9spCX6q7ldSd8VwpAqCjAmcY4DT?usp=sharing

5. Running MATLAB scripts
-The sections within "final_solution.m" script may be run individually, they require no particular running sequence - each section is fully operational individually.
-The sections of "final_project_starter_cap4630_with_answers.m" are to be run sequentially or all at once.

Expected format of contents of training data set folder to be used with final_solution.m:

JPEG images, with names in format: 
"train/cat" and "train/dog": cat.12*.jpg and dog.12*.jpg, respectively
hotdogs and not hotdogs: 
"hd_testing/hot_dog" and "hd_testing/not_hot_dog":  *.jpg and *.jpg
"theData/HotdogImages/hot_dog" and "theData/HotdogImages/not_hot_dog": hotdog.*.jpg and notHotdog.*.jpg, respectively
The aformentioned files should not be in any subdirectories within the data set folder.

* asterisks used in filenames is for wildcard character
