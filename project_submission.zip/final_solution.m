%% Baseline classifier
model = alexnet;

dataFolder = './train';

% Creates the directory for cats and dogs and moves 611 to each folder
try
    movefile('./train/cat.12*.jpg', './train/cat');
    movefile('./train/dog.12*.jpg', './train/dog');
catch
    warning('Files not available to be moved.');
end

categories = {'cat', 'dog'};
imds = imageDatastore(fullfile(dataFolder, categories), 'LabelSource', 'foldernames');

% Use the smallest overlap set
% (useful when the two classes have different number of elements but not
% needed in this case)
tbl = countEachLabel(imds);
disp (tbl)
minSetCount = min(tbl{:,2});

% Use splitEachLabel method to trim the set.
imds = splitEachLabel(imds, minSetCount, 'randomize');


% Set the ImageDatastore ReadFcn
imds.ReadFcn = @(filename)readAndPreprocessImage(filename);

% Divide data into training and validation sets
[trainingSet, validationSet] = splitEachLabel(imds, 0.8, 'randomized');

layersTransfer = model.Layers(1:end-3);
numClasses = 2; % cat and dog

layers = [
    layersTransfer
    fullyConnectedLayer(numClasses,'WeightLearnRateFactor',20,'BiasLearnRateFactor',20)
    softmaxLayer
    classificationLayer];

%Configuring training options
options = trainingOptions('sgdm', ...
    'MiniBatchSize',10, ...
    'MaxEpochs',6, ...
    'InitialLearnRate',1e-4, ...
    'Shuffle','every-epoch', ...
    'ValidationData',validationSet, ...
    'ValidationFrequency',3, ... %3
    'Verbose',false, ...
    'Plots','training-progress');

% Retrain network

modelTransfer = trainNetwork(trainingSet,layers,options);

% Classify the validation images using the fine-tuned network.

[YPred,scores] = classify(modelTransfer,validationSet);

% Calculate the classification accuracy on the validation set. 
% Accuracy is the fraction of labels that the network predicts correctly.

YValidation = validationSet.Labels;
Yaccuracy = mean(YPred == YValidation);

fprintf("The validation accuracy is: %.2f %%\n", Yaccuracy * 100);

%Putting files back into parent directory
try
    movefile('./train/cat/cat.*.jpg', './train');
    movefile('./train//dog/dog.*.jpg', './train');
catch
    warning('Files not available to be moved.');
end

%  ~Testing Accuracy~
%Creating datastore of images of cats and dogs and labeling them according
%to the folder they were in
timds = imageDatastore('./testing', 'IncludeSubfolders', true, 'LabelSource', 'foldernames');
%Getting labels
animalActual = timds.Labels;
%Processing images
timds.ReadFcn = @readAndPreprocessImage;
%Getting predictions for each image in timds datastore
animalPreds = classify(modelTransfer, timds)
%Getting the total number of correctly predicted
numCorrect = nnz(animalPreds == animalActual)
%Calculating and printing test accuracy
testAccuracy = numCorrect/(numel(animalPreds));
fprintf("The test accuracy is: %.2f %%\n", testAccuracy * 100);
%Displaying confusion matrix
confusionchart(animalActual, animalPreds)


%% Improved classifier 1 - Data augmentation
model = alexnet;

dataFolder = './train';

% Creates the directory for cats and dogs and moves 611 to each folder
try
    movefile('./train/cat.12*.jpg', './train/cat');
    movefile('./train/dog.12*.jpg', './train/dog');
catch
    warning('Files not available to be moved.');
end

categories = {'cat', 'dog'};
imds = imageDatastore(fullfile(dataFolder, categories), 'LabelSource', 'foldernames');

% Use the smallest overlap set
% (useful when the two classes have different number of elements but not
% needed in this case)
tbl = countEachLabel(imds);
disp (tbl)
minSetCount = min(tbl{:,2});

% Use splitEachLabel method to trim the set.
imds = splitEachLabel(imds, minSetCount, 'randomize');


% Set the ImageDatastore ReadFcn
imds.ReadFcn = @(filename)readAndPreprocessImage(filename);

% Divide data into training and validation sets
[trainingSet, validationSet] = splitEachLabel(imds, 0.8, 'randomized');

layersTransfer = model.Layers(1:end-3);
numClasses = 2; % cat and dog

layers = [
    layersTransfer
    fullyConnectedLayer(numClasses,'WeightLearnRateFactor',20,'BiasLearnRateFactor',20)
    softmaxLayer
    classificationLayer];

%Configuring training options
options = trainingOptions('sgdm', ...
    'MiniBatchSize',10, ...
    'MaxEpochs',6, ...
    'InitialLearnRate',1e-4, ...
    'Shuffle','every-epoch', ...
    'ValidationData',validationSet, ...
    'ValidationFrequency',3, ... %3
    'Verbose',false, ...
    'Plots','training-progress');

% Retrain network

modelTransfer = trainNetwork(trainingSet,layers,options);
%
%Augmentation starts here
% Defining the imageAugmenter object 
pixelRange = [-30 30];
scaleRange = [0.9 1.1];
imageAugmenter = imageDataAugmenter( ...
    'RandXReflection',true, ...
    'RandXTranslation',pixelRange, ...
    'RandYTranslation',pixelRange, ...
    'RandXScale',scaleRange, ...
    'RandYScale',scaleRange);

% Building the augmented training and validation sets
inputSize = model.Layers(1).InputSize;
augimdsTrain = augmentedImageDatastore(inputSize(1:2),trainingSet, ...
    'DataAugmentation',imageAugmenter);

disp(augimdsTrain.NumObservations) % You should see 978

augimdsValidation = augmentedImageDatastore(inputSize(1:2),validationSet);

disp(augimdsValidation.NumObservations) % You should see 244

% Train the network with augmented datasets

miniBatchSize = 10;
options = trainingOptions('sgdm', ...
    'MiniBatchSize',miniBatchSize, ...
    'MaxEpochs',8, ...
    'InitialLearnRate',3e-4, ...
    'ValidationData',augimdsValidation, ...
    'Verbose',false, ...
    'Plots','training-progress');

modelAug = trainNetwork(augimdsTrain,layers,options);

% Classify the validation images using the fine-tuned network.

[YPredAug,probsAug] = classify(modelAug,augimdsValidation);

% Calculate the classification accuracy on the validation set. 

YValidationAug = validationSet.Labels;
accuracyAug = mean(YPredAug == YValidationAug);
fprintf("The validation accuracy is: %.2f %%\n", accuracyAug * 100);

%Putting files back into parent directory
try
    movefile('./train/cat/cat.*.jpg', './train');
    movefile('./train//dog/dog.*.jpg', './train');
catch
    warning('Files not available to be moved.');
end

% ~Testing Accuracy~
%Creating datastore of images of cats and dogs and labeling them according
%to the folder they were in
timds = imageDatastore('./testing', 'IncludeSubfolders', true, 'LabelSource', 'foldernames');
%Getting labels
animalActual = timds.Labels;
%Processing images
timds.ReadFcn = @readAndPreprocessImage;
%Getting predictions for each image in timds datastore
animalPreds = classify(modelAug, timds)
%Getting the total number of correctly predicted
numCorrect = nnz(animalPreds == animalActual)
%Calculating and printing test accuracy
testAccuracy = numCorrect/(numel(animalPreds));
fprintf("The test accuracy is: %.2f %%\n", testAccuracy * 100);
%Displaying confusion matrix
confusionchart(animalActual, animalPreds)


%% Improved classifier 2 - Baseline classifier with InitialLearningRate = 0.00001
model = alexnet;


dataFolder = './train';

% Creates the directory for cats and dogs and moves 611 to each folder
try
    movefile('./train/cat.12*.jpg', './train/cat');
    movefile('./train/dog.12*.jpg', './train/dog');
catch
    warning('Files not available to be moved.');
end

categories = {'cat', 'dog'};
imds = imageDatastore(fullfile(dataFolder, categories), 'LabelSource', 'foldernames');

% Use the smallest overlap set
% (useful when the two classes have different number of elements but not
% needed in this case)
tbl = countEachLabel(imds);
disp (tbl)
minSetCount = min(tbl{:,2});

% Use splitEachLabel method to trim the set.
imds = splitEachLabel(imds, minSetCount, 'randomize');


% Set the ImageDatastore ReadFcn
imds.ReadFcn = @(filename)readAndPreprocessImage(filename);

% Divide data into training and validation sets
[trainingSet, validationSet] = splitEachLabel(imds, 0.8, 'randomized');

layersTransfer = model.Layers(1:end-3);
numClasses = 2; % cat and dog

layers = [
    layersTransfer
    fullyConnectedLayer(numClasses,'WeightLearnRateFactor',20,'BiasLearnRateFactor',20)
    softmaxLayer
    classificationLayer];

%Configuring training options
options = trainingOptions('sgdm', ...
    'MiniBatchSize',10, ...
    'MaxEpochs',6, ...
    'InitialLearnRate',1e-5, ...
    'Shuffle','every-epoch', ...
    'ValidationData',validationSet, ...
    'ValidationFrequency',3, ... %3
    'Verbose',false, ...
    'Plots','training-progress');

% Retrain network

modelTransfer = trainNetwork(trainingSet,layers,options);

% Classify the validation images using the fine-tuned network.

[YPred,scores] = classify(modelTransfer,validationSet);

% Calculate the classification accuracy on the validation set. 
% Accuracy is the fraction of labels that the network predicts correctly.

YValidation = validationSet.Labels;
Yaccuracy = mean(YPred == YValidation);

fprintf("The validation accuracy is: %.2f %%\n", Yaccuracy * 100);

%Putting files back into parent directory
try
    movefile('./train/cat/cat.*.jpg', './train');
    movefile('./train/dog/dog.*.jpg', './train');
catch
    warning('Files not available to be moved.');
end

% ~Testing Accuracy~
%Creating datastore of images of cats and dogs and labeling them according
%to the folder they were in
timds = imageDatastore('./testing', 'IncludeSubfolders', true, 'LabelSource', 'foldernames');
%Getting labels
animalActual = timds.Labels;
%Processing images
timds.ReadFcn = @readAndPreprocessImage;
%Getting predictions for each image in timds datastore
animalPreds = classify(modelTransfer, timds)
%Getting the total number of correctly predicted
numCorrect = nnz(animalPreds == animalActual)
%Calculating and printing test accuracy
testAccuracy = numCorrect/(numel(animalPreds));
fprintf("The test accuracy is: %.2f %%\n", testAccuracy * 100);
%Displaying confusion matrix
confusionchart(animalActual, animalPreds)


%% Bonus Opportunities Part 1 - Deeper Understanding of the Solution
%Modifications to the solution: Baseline classifier with ValidationFrequency = 1
model = alexnet;

dataFolder = './train';

% Creates the directory for cats and dogs and moves 611 to each folder
try
    movefile('./train/cat.12*.jpg', './train/cat');
    movefile('./train/dog.12*.jpg', './train/dog');
catch
    warning('Files not available to be moved.');
end

categories = {'cat', 'dog'};
imds = imageDatastore(fullfile(dataFolder, categories), 'LabelSource', 'foldernames');

% Use the smallest overlap set
% (useful when the two classes have different number of elements but not
% needed in this case)
tbl = countEachLabel(imds);
disp (tbl)
minSetCount = min(tbl{:,2});

% Use splitEachLabel method to trim the set.
imds = splitEachLabel(imds, minSetCount, 'randomize');


% Set the ImageDatastore ReadFcn
imds.ReadFcn = @(filename)readAndPreprocessImage(filename);

% Divide data into training and validation sets
[trainingSet, validationSet] = splitEachLabel(imds, 0.8, 'randomized');

layersTransfer = model.Layers(1:end-3);
numClasses = 2; % cat and dog

layers = [
    layersTransfer
    fullyConnectedLayer(numClasses,'WeightLearnRateFactor',20,'BiasLearnRateFactor',20)
    softmaxLayer
    classificationLayer];

%Configuring training options
options = trainingOptions('sgdm', ...
    'MiniBatchSize',10, ...
    'MaxEpochs',6, ...
    'InitialLearnRate',1e-4, ...
    'Shuffle','every-epoch', ...
    'ValidationData',validationSet, ...
    'ValidationFrequency',1, ... %3
    'Verbose',false, ...
    'Plots','training-progress');

% Retrain network

modelTransfer = trainNetwork(trainingSet,layers,options);

% Classify the validation images using the fine-tuned network.

[YPred,scores] = classify(modelTransfer,validationSet);

% Calculate the classification accuracy on the validation set. 
% Accuracy is the fraction of labels that the network predicts correctly.

YValidation = validationSet.Labels;
Yaccuracy = mean(YPred == YValidation);

fprintf("The validation accuracy is: %.2f %%\n", Yaccuracy * 100);

%Putting files back into parent directory
try
    movefile('./train/cat/cat.*.jpg', './train');
    movefile('./train/dog/dog.*.jpg', './train');
catch
    warning('Files not available to be moved.');
end
% ~Testing Accuracy~
%Creating datastore of images of cats and dogs and labeling them according
%to the folder they were in
timds = imageDatastore('./testing', 'IncludeSubfolders', true, 'LabelSource', 'foldernames');
%Getting labels
animalActual = timds.Labels;
%Processing images
timds.ReadFcn = @readAndPreprocessImage;
%Getting predictions for each image in timds datastore
animalPreds = classify(modelTransfer, timds)
%Getting the total number of correctly predicted
numCorrect = nnz(animalPreds == animalActual)
%Calculating and printing test accuracy
testAccuracy = numCorrect/(numel(animalPreds));
fprintf("The test accuracy is: %.2f %%\n", testAccuracy * 100);
%Displaying confusion matrix
confusionchart(animalActual, animalPreds)

%% Bonus Opportunities Part 2 - Different Images and Scope - Hotdog vs Not Hotdog
model = alexnet;

dataFolder = './theData/HotdogImages';
categories = {'hot_dog', 'not_hot_dog'};
imds = imageDatastore(fullfile(dataFolder, categories), 'LabelSource', 'foldernames');
tbl = countEachLabel(imds);
disp (tbl)

% Use the smallest overlap set
% (useful when the two classes have different number of elements but not
% needed in this case)
minSetCount = min(tbl{:,2});

% Use splitEachLabel method to trim the set.
imds = splitEachLabel(imds, minSetCount, 'randomize');

% Notice that each set now has exactly the same number of images.
countEachLabel(imds)

% Set the ImageDatastore ReadFcn
imds.ReadFcn = @(filename)readAndPreprocessImage(filename);

%  Divide data into training and validation sets
[trainingSet, validationSet] = splitEachLabel(imds, 0.8, 'randomized');

countEachLabel(trainingSet)
countEachLabel(validationSet)

% Freeze all but last three layers

layersTransfer = model.Layers(1:end-3);
numClasses = 2; % hotdog and not

layers = [
    layersTransfer
    fullyConnectedLayer(numClasses,'WeightLearnRateFactor',20,'BiasLearnRateFactor',20)
    softmaxLayer
    classificationLayer];

% Configure training options

options = trainingOptions('sgdm', ...
    'MiniBatchSize',10, ...
    'MaxEpochs',6, ...
    'InitialLearnRate',1e-4, ...
    'Shuffle','every-epoch', ...
    'ValidationData',validationSet, ...
    'ValidationFrequency',3, ...
    'Verbose',false, ...
    'Plots','training-progress');

% Retrain network

modelTransfer = trainNetwork(trainingSet,layers,options);

% Classify the validation images using the fine-tuned network.

[YPred,scores] = classify(modelTransfer,validationSet);

% Calculate the classification accuracy on the validation set. 
% Accuracy is the fraction of labels that the network predicts correctly.

YValidation = validationSet.Labels;
accuracy = mean(YPred == YValidation);
fprintf("The validation accuracy is: %.2f %%\n", accuracy * 100);

% Test it on unseen images
newImage1 = './hotdog.jpg'; 
img1 = readAndPreprocessImage(newImage1);
YPred1 = predict(modelTransfer,img1);
[confidence1,idx1] = max(YPred1);
label1 = categories{idx1};
% Display test image and assigned label
figure
imshow(img1)
title(string(label1) + ", " + num2str(100*confidence1) + "%");

newImage2 = './notHotdog.jpg'; 
img2 = readAndPreprocessImage(newImage2);
YPred2 = predict(modelTransfer,img2);
[confidence2,idx2] = max(YPred2);
label2 = categories{idx2};
% Display test image and assigned label
figure
imshow(img2)
title(string(label2) + ", " + num2str(100*confidence2) + "%");
   
% Test it on unseen images: Your turn!

newImage3 = './hotdoge.jpg';
img3 = readAndPreprocessImage(newImage3);
YPred3 = predict(modelTransfer,img3);
[confidence3,idx3] = max(YPred3);
label3 = categories{idx3};
% Display test image and assigned label
figure
imshow(img3)
title(string(label3) + ", " + num2str(100*confidence3) + "%");

% Defining the imageAugmenter object 
% In our case, we shall use an augmented image datastore to randomly flip
% the training images along the vertical axis and randomly translate them
% up to 30 pixels and scale them up to 10% horizontally and vertically.

pixelRange = [-30 30];
scaleRange = [0.9 1.1];
imageAugmenter = imageDataAugmenter( ...
    'RandXReflection',true, ...
    'RandXTranslation',pixelRange, ...
    'RandYTranslation',pixelRange, ...
    'RandXScale',scaleRange, ...
    'RandYScale',scaleRange);

% Building the augmented training and validation sets

inputSize = model.Layers(1).InputSize;
augimdsTrain = augmentedImageDatastore(inputSize(1:2),trainingSet, ...
    'DataAugmentation',imageAugmenter);

disp(augimdsTrain.NumObservations) 

augimdsValidation = augmentedImageDatastore(inputSize(1:2),validationSet);

disp(augimdsValidation.NumObservations) 

% Train the network with augmented datasets

miniBatchSize = 10;
options = trainingOptions('sgdm', ...
    'MiniBatchSize',miniBatchSize, ...
    'MaxEpochs',8, ...
    'InitialLearnRate',3e-4, ...
    'ValidationData',augimdsValidation, ...
    'Verbose',false, ...
    'Plots','training-progress');

modelAug = trainNetwork(augimdsTrain,layers,options);

% Classify the validation images using the fine-tuned network.

[YPredAug,probsAug] = classify(modelAug,augimdsValidation);

% Calculate the classification accuracy on the validation set. 
% Accuracy is the fraction of labels that the network predicts correctly.

YValidationAug = validationSet.Labels;
accuracyAug = mean(YPredAug == YValidationAug);
fprintf("The validation accuracy is: %.2f %%\n", accuracyAug * 100);

% Part 5: Larger datasets

model = alexnet;

dataFolder2 = './hd_train';

categories2 = {'hot_dog', 'not_hot_dog'};
imds2 = imageDatastore(fullfile(dataFolder2, categories2), 'LabelSource', 'foldernames');
tbl = countEachLabel(imds2);
disp (tbl)

% Use the smallest overlap set
% (useful when the two classes have different number of elements but not
% needed in this case)
minSetCount = min(tbl{:,2});
% Use the smallest overlap set
% (useful when the two classes have different number of elements but not
% needed in this case)


% Use splitEachLabel method to trim the set.
imds2 = splitEachLabel(imds2, minSetCount, 'randomize');


% Set the ImageDatastore ReadFcn
imds2.ReadFcn = @(filename)readAndPreprocessImage(filename);

% Divide data into training and validation sets
[trainingSet2, validationSet2] = splitEachLabel(imds2, 0.8, 'randomized');

layersTransfer = model.Layers(1:end-3);
numClasses = 2; % hotdog and not

layers = [
    layersTransfer
    fullyConnectedLayer(numClasses,'WeightLearnRateFactor',20,'BiasLearnRateFactor',20)
    softmaxLayer
    classificationLayer];

%Configuring training options
options = trainingOptions('sgdm', ...
    'MiniBatchSize',10, ...
    'MaxEpochs',6, ...
    'InitialLearnRate',1e-4, ...
    'Shuffle','every-epoch', ...
    'ValidationData',validationSet2, ...
    'ValidationFrequency',3, ...
    'Verbose',false, ...
    'Plots','training-progress');

% Retrain network

modelTransfer2 = trainNetwork(trainingSet2,layers,options);

% Classify the validation images using the fine-tuned network.

[YPred,scores] = classify(modelTransfer,validationSet2);

% Calculate the classification accuracy on the validation set. 
% Accuracy is the fraction of labels that the network predicts correctly.

YValidation = validationSet2.Labels;
Yaccuracy = mean(YPred == YValidation);

fprintf("The validation accuracy is: %.2f %%\n", Yaccuracy * 100);

% ~Testing Accuracy~
%Creating datastore of images of hotdogs and nothotdogs and labeling them according
%to the folder they were in
timds = imageDatastore('./hd_testing', 'IncludeSubfolders', true, 'LabelSource', 'foldernames');
%Getting labels
animalActual = timds.Labels;
%Processing images
timds.ReadFcn = @readAndPreprocessImage;
%Getting predictions for each image in timds datastore
animalPreds = classify(modelAug, timds)
%Getting the total number of correctly predicted
numCorrect = nnz(animalPreds == animalActual)
%Calculating and printing test accuracy
testAccuracy = numCorrect/(numel(animalPreds));
fprintf("The test accuracy is: %.2f %%\n", testAccuracy * 100);
%Displaying confusion matrix
confusionchart(animalActual, animalPreds)
%% Local function definitions

% Read and pre-process images
% Copyright 2016 The MathWorks, Inc.
function Iout = readAndPreprocessImage(filename)

I = imread(filename);

% Some images may be grayscale. Replicate the image 3 times to
% create an RGB image.
if ismatrix(I)
    I = cat(3,I,I,I);
end

% Resize the image as required for the CNN.
Iout = imresize(I, [227 227]);

end